import React from 'react';

function App() {
  return (
    <main style={{ textAlign: 'center', marginTop: '20vh' }}>
      <h1>Hello World</h1>
    </main>
  );
}

export default App;

